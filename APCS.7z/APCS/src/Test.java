public class Test {

	public static void main(String[] args) {
		int[] arr = { 1, 2 };
		// arr = countEvens(arr);

		System.out.println(has12(arr));
		/*
		 * for (int i = 0; i < arr.length; i++) { System.out.printf("%d, ", arr[i]); }
		 */
	}

	public static boolean has12(int[] nums) {
		int onePos = -1;
		for (int i = 0; i < nums.length & onePos == -1; i++) {
			if (nums[i] == 1) {
				onePos = i;
			}
		}
		if (onePos != -1) {
			for (int i = onePos; i < nums.length; i++) {
				if (nums[i] == 2) {
					return true;
				}
			}
		}
		return false;
	}
}
